package com.example.machinetest.AdptersAndDataModule.data

data class Support(
    val text: String,
    val url: String
)