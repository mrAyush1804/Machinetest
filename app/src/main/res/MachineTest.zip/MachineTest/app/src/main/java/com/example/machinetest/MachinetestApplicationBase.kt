package com.example.machinetest

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MachinetestApplicationBase:Application(){
}